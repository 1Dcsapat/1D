/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Felhasználó
 */
public class AmobaJatek extends JFrame implements ActionListener{
        public int palyaszam=NyitoAblak.szam;
        public int gyozelemszam=NyitoAblak.nyerszam;
        public boolean player1=true;
        public Icon xIcon;
        public Icon oIcon;
        AmobaButton[][] cella=new AmobaButton[palyaszam][palyaszam];
        public AmobaJatek(){
            init();
            setVisible(true);
        }
        void init(){
            //palyaszam=NyitoAblak.szam;
            //gyozelemszam=NyitoAblak.nyerszam;
            setSize(900,900);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            //System.out.println("Nulla "+palyaszam);
            
            JPanel panel=new JPanel();
            panel.setLayout(new GridLayout(palyaszam,palyaszam));
            setContentPane(panel);
            
            for (int i = 0; i < palyaszam; i++) {
                for (int j = 0; j < palyaszam; j++) {
                    cella[i][j]=new AmobaButton();
                    panel.add(cella[i][j]);
                    cella[i][j].addActionListener(this);
                    cella[i][j].koordi=i;
                    cella[i][j].koordj=j;
                    cella[i][j].state=0;
                }
            }
        }
        
        public void init_icons(){
            try{
            Image x= ImageIO.read(AmobaJatek.class.getResource("/x.png"));
            Image o= ImageIO.read(AmobaJatek.class.getResource("/o.png"));
            
            xIcon=new ImageIcon(x.getScaledInstance(cella[0][0].getWidth(), cella[0][0].getHeight(), Image.SCALE_SMOOTH));
            oIcon=new ImageIcon(o.getScaledInstance(cella[0][0].getWidth(), cella[0][0].getHeight(), Image.SCALE_SMOOTH));
            
            }
            catch(IOException e){
                System.out.println("valamihülyeség");
            }
            }

    public static void main(String[] args) {
        
    
}

    @Override
    public void actionPerformed(ActionEvent ae) {
        //throw new UnsupportedOperationException("Not supported yet."); 
        AmobaButton button=(AmobaButton)(ae.getSource());
        
        System.out.println(button.getX()+"  "+button.getY());
        if(player1){
            init_icons();
            button.setIcon(xIcon);
            player1=false;
            button.setEnabled(false);
            button.state=1;
            wincheck(button);
        }
        else if(player1==false){
          init_icons();
          button.setIcon(oIcon);
          player1=true;
          button.setEnabled(false);
          button.state=2;
          wincheck(button);
        }
    }
    
    
    public void wincheck(AmobaButton button){
        int kordi=button.koordi;
        int kordj=button.koordj;
        int gyozott=1;
        
        for (int i = 1; i <= gyozelemszam; i++) {
            if(kordi+1<palyaszam)
            if(cella[kordi+1][kordj].state==button.state) {
                    gyozott++;
                if(gyozott==gyozelemszam) System.out.println("győzött!!!!!");
            }
        }
         
        
    }

}
